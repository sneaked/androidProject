package com.ngot.dnd;

import android.graphics.Bitmap;

public class BackGround extends Sprite {

	public BackGround(int index, Bitmap[] imgs, float x, float y) {
		super(index, imgs, x, y);
		initAnimation(0, 8, 4);
		
	}


	


}
