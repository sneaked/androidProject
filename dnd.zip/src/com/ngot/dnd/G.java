package com.ngot.dnd;

public class G {
	
	public static int level = 0;
}
