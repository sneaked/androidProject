package com.ngot.dnd;

public class G {
	
	public static int level = 1;
	public static int wave = 1;
}
