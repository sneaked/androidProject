package com.ngot.dnd;

public class G {
	
	public static int level = 0;
	public static int wave = 0;
}
